(function () {
  'use strict';

  /* ─── NAV SCROLL BEHAVIOUR ─── */
  var nav = document.getElementById('nav');
  var prev = 0, ticking = false;

  function onScroll() {
    var y = window.pageYOffset;
    if (y > 60) { nav.classList.add('scrolled'); } else { nav.classList.remove('scrolled'); }
    if (y > prev + 8 && y > 320) { nav.classList.add('up'); }
    else if (y < prev - 8) { nav.classList.remove('up'); }
    prev = y;
    ticking = false;
  }

  window.addEventListener('scroll', function () {
    if (!ticking) { requestAnimationFrame(onScroll); ticking = true; }
  }, { passive: true });

  /* ─── MOBILE DRAWER ─── */
  var hbg = document.getElementById('hbg');
  var drawer = document.getElementById('drawer');
  var dcl = document.getElementById('dcl');

  function openDrawer() {
    drawer.classList.add('open');
    drawer.setAttribute('aria-hidden', 'false');
    document.body.style.overflow = 'hidden';
    if (hbg) hbg.setAttribute('aria-expanded', 'true');
  }

  function closeDrawer() {
    drawer.classList.remove('open');
    drawer.setAttribute('aria-hidden', 'true');
    document.body.style.overflow = '';
    if (hbg) hbg.setAttribute('aria-expanded', 'false');
  }

  if (hbg) hbg.addEventListener('click', openDrawer);
  if (dcl) dcl.addEventListener('click', closeDrawer);
  document.querySelectorAll('.dl').forEach(function (el) {
    el.addEventListener('click', closeDrawer);
  });
  if (drawer) {
    drawer.addEventListener('click', function (e) {
      if (e.target === drawer) closeDrawer();
    });
  }

  /* ─── SCROLL REVEAL ─── */
  var io = new IntersectionObserver(function (entries) {
    entries.forEach(function (e) {
      if (e.isIntersecting) {
        e.target.classList.add('in');
        io.unobserve(e.target);
      }
    });
  }, { threshold: 0.08, rootMargin: '0px 0px -20px 0px' });

  document.querySelectorAll('.fade').forEach(function (el) {
    /* Hero elements reveal immediately without animation */
    if (el.closest('.hero-main') || el.closest('.page-hero')) {
      setTimeout(function () {
        var s = el.style.transition;
        el.style.transition = 'none';
        el.classList.add('in');
        requestAnimationFrame(function () { el.style.transition = s; });
      }, 80);
    } else {
      io.observe(el);
    }
  });

  /* ─── COUNTER ANIMATION ─── */
  var cio = new IntersectionObserver(function (entries) {
    entries.forEach(function (e) {
      if (e.isIntersecting) {
        runCount(e.target);
        cio.unobserve(e.target);
      }
    });
  }, { threshold: 0.5 });

  document.querySelectorAll('.cnt').forEach(function (el) { cio.observe(el); });

  function runCount(el) {
    var target = parseInt(el.getAttribute('data-n'), 10);
    var dur = 1200, start = null;
    function step(ts) {
      if (!start) start = ts;
      var p = Math.min((ts - start) / dur, 1);
      var ease = 1 - Math.pow(1 - p, 3);
      el.textContent = Math.round(ease * target);
      if (p < 1) { requestAnimationFrame(step); } else { el.textContent = target; }
    }
    requestAnimationFrame(step);
  }

  /* ─── ROLE / ENQUIRY TYPE SELECTOR ─── */
  var wauBtns = document.querySelectorAll('.wau-btn');
  var etype = document.getElementById('etype');

  wauBtns.forEach(function (b) {
    b.addEventListener('click', function () {
      wauBtns.forEach(function (x) { x.classList.remove('on'); });
      b.classList.add('on');
      if (etype) etype.value = b.getAttribute('data-v');
    });
  });

  /* ─── CONTACT FORM (FormSubmit) ─── */
  var form = document.getElementById('cform');
  var fok = document.getElementById('fok');
  var sbtn = document.getElementById('sbtn');

  if (form) {
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      if (sbtn) { sbtn.disabled = true; sbtn.textContent = 'Sending\u2026'; }

      var data = {};
      new FormData(form).forEach(function (v, k) { data[k] = v; });

      fetch('https://formsubmit.co/ajax/thedreamstate.steve@gmail.com', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
        body: JSON.stringify(data)
      })
        .then(function (r) {
          if (r.ok) {
            form.style.display = 'none';
            if (fok) fok.classList.add('show');
          } else {
            if (sbtn) { sbtn.disabled = false; sbtn.textContent = 'Try again'; }
          }
        })
        .catch(function () {
          if (sbtn) { sbtn.disabled = false; sbtn.textContent = 'Try again'; }
        });
    });
  }

})();
